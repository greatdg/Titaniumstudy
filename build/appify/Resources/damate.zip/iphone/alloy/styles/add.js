module.exports = [ {
    isClass: true,
    priority: 10000.0002,
    key: "container",
    style: {
        layout: "vertical"
    }
}, {
    isClass: true,
    priority: 10000.0003,
    key: "upperView",
    style: {
        layout: "horizontal",
        height: 80
    }
}, {
    isClass: true,
    priority: 10000.0004,
    key: "personalView",
    style: {
        layout: "vertical",
        height: 80
    }
}, {
    isClass: true,
    priority: 10000.0005,
    key: "rowPersonal",
    style: {
        layout: "horizontal"
    }
} ];