module.exports = [ {
    isApi: true,
    priority: 1000.0009,
    key: "Label",
    style: {
        textAlign: Ti.UI.TEXT_ALIGNMENT_LEFT,
        left: "180",
        top: "10"
    }
}, {
    isClass: true,
    priority: 10000.0008,
    key: "container",
    style: {}
}, {
    isClass: true,
    priority: 10000.001,
    key: "imageFace",
    style: {
        width: "200",
        height: "300"
    }
} ];