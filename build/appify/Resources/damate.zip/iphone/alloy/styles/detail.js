module.exports = [ {
    isClass: true,
    priority: 10000.0007,
    key: "container",
    style: {}
} ];