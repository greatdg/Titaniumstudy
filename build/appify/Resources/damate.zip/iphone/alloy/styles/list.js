module.exports = [ {
    isClass: true,
    priority: 10000.0011,
    key: "container",
    style: {}
} ];