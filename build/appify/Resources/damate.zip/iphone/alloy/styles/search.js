module.exports = [ {
    isApi: true,
    priority: 1000.0012,
    key: "Window",
    style: {
        backgroundColor: "#FFF"
    }
}, {
    isClass: true,
    priority: 10000.0013,
    key: "container",
    style: {}
} ];