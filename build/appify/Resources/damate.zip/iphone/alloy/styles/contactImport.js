module.exports = [ {
    isClass: true,
    priority: 10000.0006,
    key: "container",
    style: {}
} ];