module.exports = {
    dependencies: {}
};