function Controller() {
    __p.require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "index";
    arguments[0] ? arguments[0]["__parentSymbol"] : null;
    arguments[0] ? arguments[0]["$model"] : null;
    arguments[0] ? arguments[0]["__itemTemplate"] : null;
    var $ = this;
    var exports = {};
    var __alloyId19 = [];
    $.__views.__alloyId21 = Alloy.createController("list", {
        id: "__alloyId21"
    });
    $.__views.__alloyId20 = Ti.UI.createTab({
        window: $.__views.__alloyId21.getViewEx({
            recurse: true
        }),
        title: "List",
        icon: __p.file("KS_nav_ui.png"),
        id: "__alloyId20"
    });
    __alloyId19.push($.__views.__alloyId20);
    $.__views.__alloyId24 = Alloy.createController("search", {
        id: "__alloyId24"
    });
    $.__views.__alloyId23 = Ti.UI.createTab({
        window: $.__views.__alloyId24.getViewEx({
            recurse: true
        }),
        title: "Search",
        icon: __p.file("KS_nav_views.png"),
        id: "__alloyId23"
    });
    __alloyId19.push($.__views.__alloyId23);
    $.__views.__alloyId27 = Alloy.createController("add", {
        id: "__alloyId27"
    });
    $.__views.__alloyId26 = Ti.UI.createTab({
        window: $.__views.__alloyId27.getViewEx({
            recurse: true
        }),
        title: "Add",
        icon: __p.file("KS_nav_ui.png"),
        id: "__alloyId26"
    });
    __alloyId19.push($.__views.__alloyId26);
    $.__views.__alloyId30 = Alloy.createController("contactImport", {
        id: "__alloyId30"
    });
    $.__views.__alloyId29 = Ti.UI.createTab({
        window: $.__views.__alloyId30.getViewEx({
            recurse: true
        }),
        title: "Import",
        icon: __p.file("KS_nav_views.png"),
        id: "__alloyId29"
    });
    __alloyId19.push($.__views.__alloyId29);
    $.__views.__alloyId33 = Alloy.createController("detail", {
        id: "__alloyId33"
    });
    $.__views.__alloyId32 = Ti.UI.createTab({
        window: $.__views.__alloyId33.getViewEx({
            recurse: true
        }),
        title: "Detail",
        icon: __p.file("KS_nav_views.png"),
        id: "__alloyId32"
    });
    __alloyId19.push($.__views.__alloyId32);
    $.__views.index = __ui.createTabGroup({
        tabs: __alloyId19,
        id: "index"
    });
    $.__views.index && $.addTopLevelView($.__views.index);
    exports.destroy = function() {};
    _.extend($, $.__views);
    $.index.open();
    _.extend($, exports);
}

var Alloy = __p.require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;