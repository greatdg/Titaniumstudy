function Controller() {
    __p.require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "detail";
    arguments[0] ? arguments[0]["__parentSymbol"] : null;
    arguments[0] ? arguments[0]["$model"] : null;
    arguments[0] ? arguments[0]["__itemTemplate"] : null;
    var $ = this;
    var exports = {};
    $.__views.detail = __ui.createWindow({
        title: "Detail",
        backgroundColor: "yellow",
        id: "detail"
    });
    $.__views.detail && $.addTopLevelView($.__views.detail);
    $.__views.__alloyId17 = Ti.UI.createView({
        id: "__alloyId17"
    });
    $.__views.detail.add($.__views.__alloyId17);
    $.__views.imageBody = Ti.UI.createImageView({
        id: "imageBody",
        image: __p.file("body.png"),
        width: "150",
        height: "50",
        left: "15",
        top: "150"
    });
    $.__views.detail.add($.__views.imageBody);
    $.__views.imageFace = Ti.UI.createImageView({
        id: "imageFace",
        image: __p.file("face.png"),
        width: "120",
        height: "150",
        left: "25",
        top: "15"
    });
    $.__views.detail.add($.__views.imageFace);
    $.__views.__alloyId18 = Ti.UI.createView({
        layout: "vertical",
        id: "__alloyId18"
    });
    $.__views.detail.add($.__views.__alloyId18);
    $.__views.name = Ti.UI.createLabel({
        textAlign: Ti.UI.TEXT_ALIGNMENT_LEFT,
        left: "180",
        top: "10",
        text: "name",
        id: "name"
    });
    $.__views.__alloyId18.add($.__views.name);
    $.__views.age = Ti.UI.createLabel({
        textAlign: Ti.UI.TEXT_ALIGNMENT_LEFT,
        left: "180",
        top: "10",
        text: "age",
        id: "age"
    });
    $.__views.__alloyId18.add($.__views.age);
    $.__views.gender = Ti.UI.createLabel({
        textAlign: Ti.UI.TEXT_ALIGNMENT_LEFT,
        left: "180",
        top: "10",
        text: "gender",
        id: "gender"
    });
    $.__views.__alloyId18.add($.__views.gender);
    $.__views.phone = Ti.UI.createLabel({
        textAlign: Ti.UI.TEXT_ALIGNMENT_LEFT,
        left: "180",
        top: "10",
        text: "phone number",
        id: "phone"
    });
    $.__views.__alloyId18.add($.__views.phone);
    $.__views.address = Ti.UI.createLabel({
        textAlign: Ti.UI.TEXT_ALIGNMENT_LEFT,
        left: "180",
        top: "10",
        text: "address",
        id: "address"
    });
    $.__views.__alloyId18.add($.__views.address);
    $.__views.relationship = Ti.UI.createLabel({
        textAlign: Ti.UI.TEXT_ALIGNMENT_LEFT,
        left: "180",
        top: "10",
        text: "relationship",
        id: "relationship"
    });
    $.__views.__alloyId18.add($.__views.relationship);
    exports.destroy = function() {};
    _.extend($, $.__views);
    arguments[0] || {};
    _.extend($, exports);
}

var Alloy = __p.require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;